package com.example.myproject;

        import androidx.appcompat.app.AppCompatActivity;

        import android.app.AlertDialog;
        import android.content.Context;
        import android.content.Intent;
        import android.database.Cursor;
        import android.os.Bundle;
        import android.database.sqlite.SQLiteDatabase;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;


public class BirthdayPlus extends AppCompatActivity implements View.OnClickListener {
    SQLiteDatabase db;
    EditText Name, Day, Month, Year;
    Button btnNewBir, btnGoBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_birthday_plus);
        btnNewBir = (Button) findViewById(R.id.btnNewBirthday);
        btnNewBir.setOnClickListener(this);
        btnGoBack = (Button) findViewById(R.id.btnGoBack);
        btnGoBack.setOnClickListener(this);
        Name = (EditText) findViewById(R.id.Name);
        Day = (EditText) findViewById(R.id.Day);
        Month = (EditText) findViewById(R.id.Month);
        Year = (EditText) findViewById(R.id.Year);
        db = openOrCreateDatabase("birthday", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS birthday (name VARCHAR,day NUMBER, month NUMBER, year NUMBER, description VARCHAR);");

    }

    @Override
    public void onClick(View v) {
        if (v == btnNewBir) {
            Cursor c = db.rawQuery("SELECT * FROM birthday ", null);
            if (
                    Name.getText().toString().trim().length() == 0 ||
                            Day.getText().toString().trim().length() == 0 ||
                            Month.getText().toString().trim().length() == 0 ||
                            Year.getText().toString().trim().length() == 0 ) {
                showMessage("Error", "Please enter all data");
                return;
            }

            else if (Day.getText().toString().trim().length() > 2  || Month.getText().toString().trim().length() > 2 || Year.getText().toString().trim().length() != 4 || Month.getText().toString().trim().length() < 1) {
                showMessage("Error", "Invalid values");
            }
            else{
                db.execSQL("INSERT INTO birthday VALUES('" + Name.getText() +
                        "','" + Day.getText() + "','" + Month.getText() + "','" + Year.getText() + "');");
                showMessage("Success", "Record added");
                clearText();
            }

        }

        if (v == btnGoBack) {
            Intent next = new Intent(BirthdayPlus.this, AddBirthday.class);
            startActivity(next);
        }


    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        Name.setText("");
        Day.setText("");
        Month.setText("");
        Year.setText("");
    }
}