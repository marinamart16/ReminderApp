package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;


public class AddBirthday extends AppCompatActivity implements View.OnClickListener {
    SQLiteDatabase db;
    EditText Name;
    Button btnViewA, btnDel, btnSearch, btnA, btnGoBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_birthday);
        btnViewA = (Button) findViewById(R.id.btnViewA);
        btnViewA.setOnClickListener(this);
        btnDel = (Button) findViewById(R.id.btnDel);
        btnDel.setOnClickListener(this);
        btnA = (Button) findViewById(R.id.btnA);
        btnA.setOnClickListener(this);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(this);
        btnGoBack = (Button) findViewById(R.id.btnGoBack);
        btnGoBack.setOnClickListener(this);
        Name = (EditText) findViewById(R.id.Name);
        db = openOrCreateDatabase("birthday", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS birthday (name VARCHAR,day NUMBER, month NUMBER, year NUMBER);");

    }

    @Override
    public void onClick(View v) {

        if (v == btnA) {
            Intent next = new Intent(AddBirthday.this, BirthdayPlus.class);
            startActivity(next);
        }

        if (v == btnViewA) {
            btnViewA = (Button) findViewById(R.id.btnViewA);
            Cursor c = db.rawQuery("SELECT * FROM birthday ORDER BY name", null);
            if (c.getCount() == 0) {
                showMessage("Error", "No birthdays found in database");
                return;
            }
            //Intent intent = new Intent(getApplicationContext(),Activities.class);
            StringBuffer buffer = new StringBuffer();
            while (c.moveToNext()) {
                buffer.append( c.getString(0).toUpperCase() + " "+ c.getString(1) + "/" +  c.getString(2) + "/" +c.getString(3) +"\n");
                //buffer.append("Day: " + c.getString(1) + "\n");
                //buffer.append("Month: " + c.getString(2) + "\n");
                //buffer.append("Year: " + c.getString(3) + "\n\n");
            }
            showMessage(" BIRTHDAY DATABASE ", buffer.toString());
        }
        if (v == btnDel) {
            if (Name.getText().toString().trim().length() == 0) {
                showMessage("Error", "Please write a name to be deleted");
                return;
            }
            Cursor c = db.rawQuery("SELECT * FROM birthday WHERE name='" + Name.getText() + "'", null);
            if (c.moveToFirst()) {
                db.execSQL("DELETE FROM birthday WHERE name='" + Name.getText() + "'");
                showMessage("Success", "The birthday of " + Name.getText().toString().toUpperCase() + " was deleted!");
            } else {
                showMessage("Error", "Invalid Name");
            }
            clearText();
        }

        if (v == btnSearch) {
            if (Name.getText().toString().trim().length() == 0) {
                showMessage("Error", "Please enter a correct name");
                return;
            }
            Cursor c = db.rawQuery("SELECT * FROM birthday WHERE name='" + Name.getText() + "'", null);
            //showMessage(c.getString(2), c.getString(3));

            if (c.moveToFirst()) {
                showMessage("The birthday of " + Name.getText().toString().toUpperCase() + " is on:", ""+ c.getString(1) + "/"+c.getString(2)  +"/" +  c.getString(3) +"");


            } else {
                showMessage("Error", "Invalid Enroll Number");
                clearText();
            }
        }
        if (v == btnGoBack) {
            Intent next = new Intent(AddBirthday.this, MainActivity.class);
            startActivity(next);
        }

    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        Name.setText("");

    }
}