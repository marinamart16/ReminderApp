package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class SeeAllBithdays extends AppCompatActivity implements View.OnClickListener {
        SQLiteDatabase db;
        EditText Name, Day, Month, Year, Description;
        Button btnNewAct, btnGoBack;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_see_all_bithdays);
            btnNewAct = (Button) findViewById(R.id.btnNewBirthday);
            btnNewAct.setOnClickListener(this);
            btnGoBack = (Button) findViewById(R.id.btnGoBack);
            btnGoBack.setOnClickListener(this);
            Name = (EditText) findViewById(R.id.Name);
            Day = (EditText) findViewById(R.id.Day);
            Month = (EditText) findViewById(R.id.Month);
            Year = (EditText) findViewById(R.id.Year);
            Description = (EditText) findViewById(R.id.desc);
            db = openOrCreateDatabase("activities", Context.MODE_PRIVATE, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS activities (name VARCHAR,day NUMBER, month NUMBER, year NUMBER, description VARCHAR);");

        }

        @Override
        public void onClick(View v) {
            if (v == btnNewAct) {
                Cursor c = db.rawQuery("SELECT * FROM activities ", null);
                if (
                        Name.getText().toString().trim().length() == 0 ||
                                Day.getText().toString().trim().length() == 0 ||
                                Month.getText().toString().trim().length() == 0 ||
                                Year.getText().toString().trim().length() == 0 ) {
                    showMessage("Error", "Please enter all data");
                    return;
                }

                else if (Day.getText().toString().trim().length() > 2  || Month.getText().toString().trim().length() > 2 || Year.getText().toString().trim().length() != 4 || Month.getText().toString().trim().length() < 1) {
                    showMessage("Error", "Invalid values");
                }
                else{
                    db.execSQL("INSERT INTO activities VALUES('" + Name.getText() +
                            "','" + Day.getText() + "','" + Month.getText() + "','" + Year.getText() + "','" + Description.getText() + "');");
                    showMessage("Success", "Record added");
                    clearText();
                }

            }

            if (v == btnGoBack) {
                Intent next = new Intent(SeeAllBithdays.this, AddActivities.class);
                startActivity(next);
            }


        }

        public void showMessage(String title, String message) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle(title);
            builder.setMessage(message);
            builder.show();
        }
        public void clearText() {
            Name.setText("");
            Day.setText("");
            Month.setText("");
            Year.setText("");
            Description.setText("");
        }
    }