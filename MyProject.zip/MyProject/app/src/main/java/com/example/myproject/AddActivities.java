package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Collections;
import java.util.Locale;

import org.w3c.dom.Text;

import java.util.Date;
import java.util.Calendar;
import java.time.DayOfWeek;

import static android.icu.text.MessagePattern.ArgType.SELECT;

public class AddActivities extends AppCompatActivity implements View.OnClickListener {
    SQLiteDatabase db;
    EditText Name;
    Button btnViewA, btnDel, btnSearch, btnA, btnGoBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        btnViewA = (Button) findViewById(R.id.btnViewA);
        btnViewA.setOnClickListener(this);
        btnDel = (Button) findViewById(R.id.btnDel);
        btnDel.setOnClickListener(this);
        btnA = (Button) findViewById(R.id.btnA);
        btnA.setOnClickListener(this);
        btnGoBack = (Button) findViewById(R.id.btnGoBack);
        btnGoBack.setOnClickListener(this);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(this);
        Name = (EditText) findViewById(R.id.Name);

        db = openOrCreateDatabase("activities", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS activities (name VARCHAR,day NUMBER, month NUMBER, year NUMBER, description VARCHAR);");

    }

    @Override
    public void onClick(View v) {

        if (v == btnA) {
            Intent next = new Intent(AddActivities.this, SeeAllBithdays.class);
            startActivity(next);
        }
        if (v == btnGoBack) {
            Intent next = new Intent(AddActivities.this, MainActivity.class);
            startActivity(next);
        }


        if (v == btnViewA) {
            btnViewA = (Button) findViewById(R.id.btnViewA);
            Cursor c = db.rawQuery("SELECT * FROM activities ORDER BY name", null);
            if (c.getCount() == 0) {
                showMessage("Error", "No activities found in database");
                return;
            }
            Intent intent = new Intent(getApplicationContext(),SeeAllBithdays.class);
            StringBuffer buffer = new StringBuffer();
            while (c.moveToNext()) {
                buffer.append(c.getString(0).toUpperCase() + " "+ c.getString(1) + "/" +  c.getString(2) + "/" +c.getString(3) +"\n");
                buffer.append("Description: " + c.getString(4) + "\n");
                buffer.append("\n");
                //buffer.append("Month: " + c.getString(2) + "\n");
                //buffer.append("Year: " + c.getString(3) + "\n\n");
            }
            showMessage(" ACTIVITIES DATABASE ", buffer.toString());
        }
        if (v == btnDel) {
            if (Name.getText().toString().trim().length() == 0) {
                showMessage("Error", "Please write a name to be deleted");
                return;
            }
            Cursor c = db.rawQuery("SELECT * FROM activities WHERE name='" + Name.getText() + "'", null);
            if (c.moveToFirst()) {
                db.execSQL("DELETE FROM activities WHERE name='" + Name.getText() + "'");
                showMessage("Success", "The activity " + Name.getText().toString().toUpperCase() + " was deleted!");
            } else {
                showMessage("Error", "Invalid Activity");
            }
            clearText();
        }

        if (v == btnSearch) {
            if (Name.getText().toString().trim().length() == 0) {
                showMessage("Error", "Please enter a correct activity");
                return;
            }
            Cursor c = db.rawQuery("SELECT * FROM activities WHERE name='" + Name.getText() + "'", null);
            //showMessage(c.getString(2), c.getString(3));

            if (c.moveToFirst()) {

                showMessage("The activity " + Name.getText().toString().toUpperCase() + " is on:", ""+ c.getString(1) + "/"+c.getString(2)  +"/" +  c.getString(3) +"\n"  + c.getString(4) + "\n");
                clearText();

            } else {
                showMessage("Error", "Invalid activity name");
                clearText();
            }
        }

    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        Name.setText("");

    }
}